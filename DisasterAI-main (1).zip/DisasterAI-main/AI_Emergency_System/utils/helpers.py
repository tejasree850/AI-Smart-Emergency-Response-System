def estimate_time(traffic):
    if traffic < 40:
        return "5 mins"
    elif traffic < 70:
        return "10 mins"
    else:
        return "20 mins"