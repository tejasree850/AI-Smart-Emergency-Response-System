import torch
import torch.nn as nn

# Simple Neural Network
class TrafficModel(nn.Module):
    def __init__(self):
        super(TrafficModel, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(3, 16),
            nn.ReLU(),
            nn.Linear(16, 1)
        )

    def forward(self, x):
        return self.fc(x)


# Load model (random weights for demo)
model = TrafficModel()

def predict_traffic():
    # Example input: time, day, weather
    sample = torch.tensor([[0.5, 0.8, 0.3]], dtype=torch.float32)
    output = model(sample)
    return int(output.item() * 100)