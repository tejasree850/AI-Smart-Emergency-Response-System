import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

X = np.array([
    [1,2,3],
    [2,3,1],
    [3,1,2]
])

y = np.array([40, 70, 90])

X = X.reshape((X.shape[0], X.shape[1], 1))

model = Sequential()
model.add(LSTM(50, activation='relu', input_shape=(3,1)))
model.add(Dense(1))

model.compile(optimizer='adam', loss='mse')
model.fit(X, y, epochs=50)

model.save("models/traffic_dl.h5")

print("Traffic DL model trained")