import numpy as np
from tensorflow.keras.models import load_model

# Load trained model
model = load_model("models/traffic_dl.h5", compile=False)

def predict_traffic():
    sample = np.array([[1, 2, 3]]).reshape((1, 3, 1))
    prediction = model.predict(sample)
    return int(prediction[0][0])