import osmnx as ox
import networkx as nx

def get_real_route(lat1, lon1, lat2, lon2):

    G = ox.graph_from_place("Vijayawada, India", network_type='drive')

    orig = ox.distance.nearest_nodes(G, lon1, lat1)
    dest = ox.distance.nearest_nodes(G, lon2, lat2)

    route = nx.shortest_path(G, orig, dest, weight='length')

    return G, route


def route_to_coords(G, route):
    return [(G.nodes[node]['y'], G.nodes[node]['x']) for node in route]