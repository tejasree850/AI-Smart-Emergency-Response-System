import joblib

model = joblib.load("models/severity_model.pkl")

def predict_severity(traffic):
    return int(model.predict([[traffic]])[0])