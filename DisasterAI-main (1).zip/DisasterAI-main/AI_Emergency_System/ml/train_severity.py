import pandas as pd
from sklearn.ensemble import RandomForestRegressor
import joblib

data = pd.read_csv("data/dataset.csv")

X = data[['traffic']]
y = data['severity']

model = RandomForestRegressor()
model.fit(X, y)

joblib.dump(model, "models/severity_model.pkl")
print("Severity model trained")