import streamlit as st
import folium
import time
from geopy.geocoders import Nominatim

# AI modules
from ml.predict_severity import predict_severity
from dl.predict_traffic import predict_traffic
from agents.dispatcher import assign_vehicle
from utils.helpers import estimate_time

# Routing
from maps.routing import get_real_route, route_to_coords

# =========================
# PAGE CONFIG
# =========================
st.set_page_config(page_title="AI Emergency System", layout="wide")

st.title("🚨 AI Smart Emergency Response System")
st.markdown("### Real-time AI + Deep Learning + Map-based Rescue System")

# =========================
# USER INPUT
# =========================
st.sidebar.header("📍 Emergency Request")

location = st.sidebar.text_input("Enter your location (e.g. Vijayawada)")

# Default location
lat, lon = 16.5062, 80.6480

# Convert location to coordinates
if location:
    try:
        geo = Nominatim(user_agent="ai_app")
        loc = geo.geocode(location)
        if loc:
            lat, lon = loc.latitude, loc.longitude
        else:
            st.warning("Location not found. Using default location.")
    except:
        st.warning("Error fetching location.")

# Emergency type
emergency = st.sidebar.selectbox(
    "🚨 Emergency Type",
    ["medical", "fire", "police"]
)

# =========================
# SOS BUTTON
# =========================
if st.sidebar.button("🔴 Request Help"):

    st.subheader("🚑 Emergency Response Status")

    # =========================
    # AI PART
    # =========================
    traffic = predict_traffic()
    severity = predict_severity(traffic)
    vehicle = assign_vehicle(emergency, severity, traffic)
    eta = estimate_time(traffic)

    # =========================
    # DISPLAY RESULTS
    # =========================
    col1, col2, col3, col4 = st.columns(4)

    col1.metric("🚑 Vehicle", vehicle)
    col2.metric("🚦 Traffic", traffic)
    col3.metric("🔥 Severity", severity)
    col4.metric("⏱ ETA", eta)

    # =========================
    # ROUTING
    # =========================
    hospital_lat, hospital_lon = 16.5100, 80.6500

    with st.spinner("🚀 Calculating optimal route..."):
        G, route = get_real_route(lat, lon, hospital_lat, hospital_lon)
        coords = route_to_coords(G, route)

    st.subheader("📍 Live Emergency Map")

    # =========================
    # GPS SIMULATION
    # =========================
    progress_bar = st.progress(0)

    for i in range(0, len(coords), max(1, len(coords)//50)):

        progress = int((i / len(coords)) * 100)
        progress_bar.progress(progress)

        m = folium.Map(location=coords[i], zoom_start=14)

        # Route
        folium.PolyLine(coords, color="blue", weight=5).add_to(m)

        # Moving ambulance
        folium.Marker(
            coords[i],
            popup="🚑 Ambulance",
            icon=folium.Icon(color="blue")
        ).add_to(m)

        # SOS location
        folium.Marker(
            [lat, lon],
            popup="🚨 SOS Location",
            icon=folium.Icon(color="red")
        ).add_to(m)

        # Hospital
        folium.Marker(
            [hospital_lat, hospital_lon],
            popup="🏥 Hospital",
            icon=folium.Icon(color="green")
        ).add_to(m)

        st.components.v1.html(m._repr_html_(), height=500)

        time.sleep(0.2)

    progress_bar.progress(100)

    st.success("✅ Emergency vehicle reached destination!")

# =========================
# FOOTER
# =========================
st.markdown("---")
st.markdown("🔹 AI-Based Emergency Response System | Developed for Smart City Simulation")