def assign_vehicle(emergency, severity, traffic):

    if severity > 85 and traffic > 70:
        return "🚑 ICU Emergency Unit"
    elif emergency == "medical":
        return "🚑 Ambulance"
    elif emergency == "fire":
        return "🚒 Fire Truck"
    else:
        return "🚓 Police Vehicle"