python -m pip install osmnx folium

python -m pip install -r requirements.txt

pip install tensorflow

python -m pip install streamlit
python -m pip install pandas
python -m pip install scikit-learn
python -m pip install joblib
python -m pip install folium
python -m pip install geopy
python -m pip install osmnx
python -m pip install networkx
python -m pip install matplotlib
python -m pip install tensorflow

.venv\Scripts\activate